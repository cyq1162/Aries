1: write software using .net 4.0, if the system is running xp error (not installed .net framework 4.0 components to download and install your own Baidu).

2: When it comes to SQLite database operation, since sqlite distinguish between x86 and x64, please extract the appropriate sqlite components according to their own system to the directory.

3: If it comes to Oracle, need to use the Oracle ODP.NET:
oracle 11 unzip Oracle.DataAccess.dll component to the directory
oracle 12 unzip Oracle.ManagedDataAccess.dll component to the directory

4: The software is shareware, there will be a corresponding limit is not registered, if the supporting software, please purchase a license, enjoy a 24-hour + free upgrades for life, thank you!